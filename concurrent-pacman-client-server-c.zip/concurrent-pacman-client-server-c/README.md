# Concurrent Pac-Man Client-Server in C

Academic Operating Systems group project implementing a concurrent Pac-Man-style game using a client-server architecture in C.

The project uses POSIX threads and inter-process communication to support game sessions between a server and terminal clients.

## Main Concepts
- C17
- POSIX threads (`pthread`)
- Named pipes / FIFOs
- Semaphores
- Mutexes and read-write locks
- Signals
- Client-server communication
- `ncurses` terminal interface
- Concurrent game sessions

## Structure
- `server/` — game server, level handling, concurrency and session management
- `client/` — terminal client and communication API

## Requirements
- POSIX-compatible environment
- GCC
- `ncurses` development library
- `make`

## Build
Build the server and client separately using the included Makefiles.

```bash
cd server
make

cd ../client
make
```

## Note
This academic group project was built on course-provided starter/base code and extended with the concurrent client-server functionality required by the assignment.

The original submission had a known limitation in the signal-based ranking/top-5 functionality.
